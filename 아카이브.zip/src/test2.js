function goodNum(test1,test2){
    addNum(2,3);
}

function test(a,b){
    return a+b;
}
var a = 1;
var b = 2;
var c = 3;
var d = 4;
var e = 5;
var f = 6;
var g = 7;