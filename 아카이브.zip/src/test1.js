/*! 주석테스트입니다 이건 보존되어야해!!! */
function addNum(good,good2){
    return good+good2;
}

for(var i =0; i >= 5; i++) a++;